

baris_produk.innerHTML = ""

var data_mentah = {
  "Arabica": [
    {
      "nama": "Arabica Gayo",
      "foto": "images/produk/product_capuchino.jpg",
      "harga": "15.000",
      "size": "250 Ml",
      "link": "https://shopee.co.id/eaifjlesjfi"
        },
    {
      "nama": "Arabica Papua",
      "foto": "images/produk/product_espresso.jpg",
      "harga": "20.000",
      "size": "250 Ml",
      "link": "https://shopee.co.id/eaifjlesjfi"
        },
     {
       "nama": "Arabica Lampung",
       "foto": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSetacllexD3p60WKRe_uwXm3KgNyVBfdrt6QuzA2XvRvyIRv4t_qj03fM&s=10",
       "harga": "18.000",
       "size": "250 Ml",
       "link": "https://shopee.co.id/eaifjlesjfi"
     },   
     {
       "nama": "Arabica typica",
       "foto": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTwXbCa2S1M8xOQX4ry3nGiPrj2CtKIOFVH2LgJQeMqnwxTWt7WI5R6cq3q&s=10",
       "harga": "20.000",
       "size": "250 Ml",
       "link": "https://shopee.co.id/eaifjlesjfi"
     }
    ],
  "Robusta": [
    {
      "nama": "Kopi Susu",
      "foto": "images/produk/product_kopi_susu.jpg",
      "harga": "10.000",
      "size": "250 Ml",
      "link": "https://shopee.co.id/eaifjlesjfi"
        },
    {
      "nama": "Black Espresso",
      "foto": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ0MHG9nDChtzQeCG0J9-KYfHeLvzotz75qeg&usqp=CAU",
      "harga": "20.000",
      "size": "250 Ml",
      "link": "https://shopee.co.id/eaifjlesjfi"
    },
    {
      "nama": "Robusta wine",
      "foto": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTFp-OvHnsddHzwR8xYA_hox-UN9H2uizdQeIq1sfh6pbUdPhKjUmN98vGD&s=10",
      "harga": "25.000",
      "size": "250 Ml",
      "link": "https://shopee.co.id/eaifjlesjfi"
    },
    {
      "nama": "Robusta Lokal",
      "foto": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSeSfCr6l3czI2oFrplQBMhBuX427W38-IACrPTdouaQ6sNWrqc6N9W91o&s=10",
      "harga": "15.000",
      "size": "250 Ml",
      "link": "https://shopee.co.id/eaifjlesjfi"
    },
    ],
  "Non Kopi": [
    {
      "nama": "Es Teh Manis",
      "foto": "https://fajar.co.id/wp-content/uploads/2023/09/IMG_0741.jpg",
      "harga": "3.000",
      "size": "250 Ml",
      "link": "https://shopee.co.id/eaifjlesjfi"
        },
    {
      "nama": "Es Tebu",
      "foto": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSw4bYqqHfzPN0FynmrTW-F7ibqPkrtzC429ht0VLhd0gJl4d9o8vV34mA&s=10",
      "harga": "5.000",
      "size": "250 Ml",
      "link": "https://shopee.co.id/eaifjlesjfi"
     },
     {
       "nama": "Es Jeruk",
       "foto": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSGJHTxK0bMzWbeodo8oGmJ9vwl1evlvtX5QA&usqp=CAU",
       "harga": "5.000",
       "size": "250 Ml",
       "link": "https://shopee.co.id/eaifjlesjfi"
     },
     {
       "nama": "Es Campur",
       "foto": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSS56hyEaonUZysiqz739chLb3AJdszeBjraiWf9DDk_x9lm4uuzDKIgnzP&s=10",
       "harga": "10.000",
       "size": "250 Ml",
       "link": "https://shopee.co.id/eaifjlesjfi"
     }
    ],
   "Jajanan": [
     {
       "nama": "Batagor",
       "foto": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQY_niJMZVFsXtFOnP0rOFWfPMaVYe6ZEaZvw8ZRzHc2O7vLii5Ne35xQM&s=10",
       "harga": "10.000",
       "size": "1pcs",
       "link": "https://shopee.co.id/eaifjlesjfi"
           },
     {
       "nama": "Siomay",
       "foto": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQY5oPkau3yfZx8ey4dhRXyUbahle3iEVDg-63ZZm7fyWLDmm00Ej_lG4r-&s=10",
       "harga": "10.000",
       "size": "1pcs",
       "link": "https://shopee.co.id/eaifjlesjfi"
        },
     {
       "nama": "Dimsum",
       "foto": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR2oyWevjAjtCf1dfU2EWVamBC3OY7bhmXxcw&usqp=CAU",
       "harga": "15.000",
       "size": "1pcs",
       "link": "https://shopee.co.id/eaifjlesjfi"
        },
     {
       "nama": "Kebab Turki",
       "foto": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR7nTMysM8Y05nWK5WjSDvVc4r4nAEsonk2Dc1rYIFa9Xy93S3GhCjTGd8&s=10",
       "harga": "14.000",
       "size": "medium",
       "link": "https://shopee.co.id/eaifjlesjfi"
        }
       ] 
}

console.log("data mentah:", data_mentah)

function updateSelect() {
  select_kopi.innerHTML = '<option selected disabled>-</option>'
  Object.keys(data_mentah).forEach(function(opsi) {
    select_kopi.innerHTML += '<option value="' + opsi + '">' + opsi + '</option>'
  })
  console.log("Melakukan Update Select")
}
updateSelect();

var data_kopi = []
select_kopi.onchange = function() {
  var pilihan = select_kopi.value
  console.log("Customer Memilih " + pilihan)
  data_kopi = data_mentah[pilihan]
  console.log("isi data_kopi = ", data_kopi)
  updateTampilan()
}

function updateTampilan() {
  baris_produk.innerHTML = ''
  data_kopi.forEach(kopi => {
    baris_produk.innerHTML += `<div class="col mb-4">
                <div class="card">
                    <img src="${kopi.foto}" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">${kopi.nama}</h5>
                        <div class="row hargasize my-4">
                            <div class="col">
                                ${kopi.size}
                            </div>
                            <div class="col text-success fw-bold">
                                ${kopi.harga}
                            </div>
                        </div>
                        <a href="${kopi.link}" class="btn btn-success w-100"><i class="bi bi-cart4"></i> Beli</a>
                    </div>
                </div>
            </div>`
  })
}
